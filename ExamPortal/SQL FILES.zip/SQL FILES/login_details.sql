-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2020 at 11:23 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_details`
--

-- --------------------------------------------------------

--
-- Table structure for table `description`
--

CREATE TABLE `description` (
  `time` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `marks` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `description`
--

INSERT INTO `description` (`time`, `description`, `marks`) VALUES
('10', 'No limit', '10');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `Name` varchar(200) NOT NULL,
  `DOB` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Mobile` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Roll` varchar(200) NOT NULL,
  `Branch` varchar(200) NOT NULL,
  `SGPA` varchar(200) NOT NULL,
  `CGPA` varchar(200) NOT NULL,
  `Tenth` varchar(200) NOT NULL,
  `Twelth` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`Name`, `DOB`, `Email`, `Mobile`, `Password`, `Roll`, `Branch`, `SGPA`, `CGPA`, `Tenth`, `Twelth`) VALUES
('RAHUL KUMAR', '2020-12-02', 'rg54622@gmail.com', '8139001736', 'Rahul@123', 'b160756cs', 'cs', '3', '6', '56', '33');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
